package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.cfg.CreateKeySecondPass;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO{
static Map<Long,Account> accmap=new HashMap<Long,Account>();
	EntityManagerFactory entity=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=entity.createEntityManager();
	@Override
	public boolean addAccount(Account ob){
		Account account=this.findAccount(ob.getMobile());
		if(account!=null) {
			System.out.println("Account with same mobile number exist");
			return false;
		}
		em.getTransaction().begin();
		em.persist(ob);
		em.flush();
		em.getTransaction().commit();
		return true;
	}

	@Override
	public boolean updateAccount(Account ob,long mob) {
		Account a=this.findAccount(mob);
		if(a==null) {
			System.out.println("No account linked to the given mobile number");
			return false;
		}
		if(ob.getMobile()!=mob) {
			this.deleteAccount(mob);
			this.addAccount(ob);
			return true;
		}
		em.getTransaction().begin();
		a.setAccountholder(ob.getAccountholder());
		a.setAid(ob.getAid());
		a.setBalance(ob.getBalance());
		em.getTransaction().commit();		
		return true;
	}

	@Override
	public boolean deleteAccount(long mob) {
		Account account=this.findAccount(mob);
		if(account==null) {
			System.out.println("No account exist with given ID");
			return false;
		}
		em.getTransaction().begin();
		em.remove(account);
		em.getTransaction().commit();
		return true;
	}

	@Override
	public Account findAccount(long mobileno) {
		em.getTransaction().begin();
		Account account=em.find(Account.class,mobileno);
		em.getTransaction().commit();
		if(account==null) {
			return null;
		}
		return account;
	}

	public void getAllAccounts() {
		em.getTransaction().begin();
		Query query=em.createQuery("select a from Account a");
		List<Account> list=query.getResultList();
		if(list.isEmpty()) {
			System.out.println("No records exist");
		}
		else {
			System.out.println("Records Successfully Fetched");
			System.out.println(list);
		}
	}

	@Override
	public boolean transferMoney(Long from,Long to,double amount) {
		Account a1=this.findAccount(from);
		Account a2=this.findAccount(to);
		if(a1==null || a2==null) {
			System.out.println("One or more accounts donot exist");
			return false;
		}
		em.getTransaction().begin();
		a1.setBalance(a1.getBalance()-amount);
		a2.setBalance(a2.getBalance()+amount);
		em.getTransaction().commit();
		return true;
		
	}
	@Override
	public double withdraw(Long mob, double amount) {
		Account a=this.findAccount(mob);
		if(this.findAccount(mob)==null) {
			System.out.println("Account does not exist");
		return 0.0;	
		}
		em.getTransaction().begin();
		double balance=a.getBalance()-amount;
		if(balance<0.0) {
			return 0.0;
		}
		a.setBalance(balance);
		em.getTransaction().commit();
		return balance;
		
	}
	public double deposit(Long mob,double amount) {
		Account a=this.findAccount(mob);
		if(a==null) {
			System.out.println("Account does not exist");
			return 0.0;
		}
		em.getTransaction().begin();
		double new_balance=a.getBalance()+amount;
		a.setBalance(new_balance);
		em.getTransaction().commit();
		return new_balance;
	}	

	
}
