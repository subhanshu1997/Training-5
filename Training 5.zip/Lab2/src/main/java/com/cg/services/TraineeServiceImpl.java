package com.cg.services;

import java.util.List;

import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.daos.TraineeDao;
import com.cg.daos.TraineeDaoImpl;
import com.cg.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService{
	TraineeDao dao=new TraineeDaoImpl();
 public void addTrainee(Trainee t) {
	 dao.addTrainee(t);
 }
public List<Trainee> fillDeleteTrainee(Integer traineeId) {
	return dao.fillDeleteTrainee(traineeId);
}
public void deleteTrainee(Integer traineeId) {
	dao.deleteTrainee(traineeId);
}
public List<Trainee> getAllTrainee(){
	return dao.getAllTrainee();
}
public List<Trainee> retrieveTrainee(Integer traineeId){
	System.out.println("Service");
	return dao.retrieveTrainee(traineeId);
}
public void modifyTrainee(Integer traineeId,Integer updatedTraineeId,String updatedTraineeName,String updatedTraineeLocation,String updatedTraineeDomain) {
	dao.modifyTrainee(traineeId,updatedTraineeId,updatedTraineeName,updatedTraineeLocation,updatedTraineeDomain);
}
}
