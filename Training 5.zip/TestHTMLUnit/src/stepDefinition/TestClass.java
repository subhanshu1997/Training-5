package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is about to open TestUnitHTMLFile$")
	public void user_is_about_to_open_TestUnitHTMLFile() throws Throwable {
	    System.out.println("User is about to open TestUnitHTMLFile");
	}

	@When("^User opens TestUnitHTMlFile$")
	public void user_opens_TestUnitHTMlFile() throws Throwable {
	    System.out.println("User opens TestUnitHTMlFile");
	}

	@Then("^TestUnitHTMLFile should open loading all necessary CSS styles$")
	public void testunithtmlfile_should_open_loading_all_necessary_CSS_styles() throws Throwable {
	    System.out.println("TestUnitHTMLFile opens loading all necessary CSS styles");
	}

}
