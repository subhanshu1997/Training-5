package com.cg.services;

import com.cg.entities.Author;

public interface AuthorService {
	public boolean create(Author author);
	public boolean delete(Integer id);
	public boolean update(Author author);
	public Author getAuthor(Integer id);

}
