package com.cg.services;


import com.cg.daos.AuthorDAO;
import com.cg.daos.AuthorDAOImpl;
import com.cg.entities.Author;

public class AuthorServiceImpl implements AuthorService{
	AuthorDAO dao=new AuthorDAOImpl();
	public boolean create(Author author) {
		return dao.create(author);
	}

	public boolean delete(Integer id) {
		return dao.delete(id);		
	}

	public boolean update(Author author) {
		return dao.update(author);
	}

	public Author getAuthor(Integer id) {
		return dao.getAuthor(id);
	}
	

}
