package com.cg.daos;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Author;

public class AuthorDAOImpl implements AuthorDAO{
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	@Override
	public boolean create(Author author) {
		if(this.getAuthor(author.getAuthorId())!=null) {
			return false;
		}
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
		return true;
	}

	@Override
	public boolean delete(Integer id) {
		if(this.getAuthor(id)==null) {
			return false;
		}
		Author a=this.getAuthor(id);
		em.getTransaction().begin();
		em.remove(a);
		em.getTransaction().commit();
		return true;
	}

	@Override
	public boolean update(Author author) {
		if(this.getAuthor(author.getAuthorId())==null)
			return false;
		Integer id=author.getAuthorId();
		this.delete(id);
		this.create(author);
		return true;
	}

	@Override
	public Author getAuthor(Integer id) {
		em.getTransaction().begin();
		Author a=em.find(Author.class,id);
		em.getTransaction().commit();
		return a;
	}

}
