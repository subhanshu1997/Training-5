package com.cg.daos;

import com.cg.entities.Author;

public interface AuthorDAO{
	public boolean create(Author author);
	public boolean delete(Integer id);
	public boolean update(Author author);
	public Author getAuthor(Integer id);

}
