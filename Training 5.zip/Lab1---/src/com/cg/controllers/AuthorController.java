package com.cg.controllers;

import com.cg.entities.Author;
import com.cg.services.AuthorService;
import com.cg.services.AuthorServiceImpl;

public class AuthorController {
	AuthorService service=new AuthorServiceImpl();
	public void create(Author author) {
		boolean flag=service.create(author);
		if(flag) {
			System.out.println("'Author created'");
		}
		else{
			System.out.println("author exists");
		}	
	}
	public void delete(Integer id) {
		boolean flag=service.delete(id);
		if(flag) {
			System.out.println("'Author Deleted'");
		}
		else{
			System.out.println("No author exists with the given AuthorId");
		}
	}
	public void update(Author author) {
		boolean flag=service.update(author);
		if(flag) {
			System.out.println("'Author Updated'");
		}
		else{
			System.out.println("No author exist with the given Author Id");
		}
		
	}
	public Author getAuthor(Integer id) {
		Author author=service.getAuthor(id);
		if(author==null) {
			System.out.println("No author with the given author id exists");
		}
		return author;
	}
	public static void main(String[] args) {
		AuthorController author=new AuthorController();
		//Adding Author
		author.create(new Author(101,"Tom","Marvolo","Riddle","9875641234"));
		//Getting Author
		System.out.println(author.getAuthor(101));
		//Updating Author
		author.update(new Author(101,"Harry","James","Potter","9875641234"));
		//Getting Author
		System.out.println(author.getAuthor(101));
		//Deleting Author
		author.delete(101);
		//Constraint Checks
		System.out.println("--------------Constraint Checks------------------------------");
		author.getAuthor(101);
		author.delete(101);
		author.update(new Author(101,"dummy1","dummy2","dummy3","9875641234"));
		
		
	}
	

}
