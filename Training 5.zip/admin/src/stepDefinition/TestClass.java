package stepDefinition;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^i am not logged in as an administrator$")
	public void i_am_not_logged_in_as_an_administrator() throws Throwable {
	    System.out.println("Logged in as admin");
	}

	@When("^I fill in the fields$")
	public void i_fill_in_the_fields(DataTable arg1) throws Throwable {
	    System.out.println(arg1.raw());
	}

	@When("^i press \"([^\"]*)\"$")
	public void i_press(String arg1) throws Throwable {
	    System.out.println("Pressed");
	}

	@Then("^I should be on the administrative page$")
	public void i_should_be_on_the_administrative_page() throws Throwable {
	    System.out.println("At admin Page");
	}

	@Then("^I should see \"([^\"]*)\"$")
	public void i_should_see(String arg1) throws Throwable {
	    System.out.println("See");
	}

}
