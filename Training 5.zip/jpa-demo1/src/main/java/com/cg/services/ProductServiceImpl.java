package com.cg.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;

import com.cg.dao.ProductDAO;
import com.cg.entities.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{
@Autowired private ProductDAO dao;

@Transactional
public Product find(int productId) {
	return dao.findById(productId);
}

public List<Product> getAll() {
	return dao.findAll();
}
@Transactional
public void create(Product p) {
	dao.save(p);	
}

}
