package com.cg.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;

@Entity
public class Book {
	@Id
	Integer ISBN;
	@Column
	String title;
	@Column
	Integer price;
	@ManyToMany(targetEntity = Author.class)
	@JoinColumn(name = "ID")
	List<Author> author;

	public Integer getISBN() {
		return ISBN;
	}

	public void setISBN(Integer iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Book(Integer iSBN, String title, Integer price) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
}
