package com.cg;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class EmployeeDetails {
public static void main(String[] args) {
	WebDriver driver=new FirefoxDriver();
	driver.get("file:///D:/HTML/login.html");
	WebElement element=driver.findElement(By.xpath("//input[@id='name']"));
	element.sendKeys("Tom");
	WebElement element1=driver.findElement(By.xpath("//input[@id='age']"));
	element1.sendKeys(String.valueOf(20));
}
}
