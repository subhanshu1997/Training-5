package userinformation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.User;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class userinformationstepdefinition {
	WebDriver driver;
	User user;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
		
	}
	
	@Given("^User is on User Information Page$")
	public void user_is_on_User_Information_Page() throws Throwable {
		user=new User(driver);
	    driver.get("D:\\Subhanshu\\Spring Boot Sps 3.9\\UserInformation1\\HTMl Files\\UserInformation.html"); 
	}

	@When("^User does not enter any text in Applicant Name field$")
	public void user_does_not_enter_any_text_in_Applicant_Name_field() throws Throwable {
	    user.setName("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Applicant Name Field is Invalid$")
	public void applicant_Name_Field_is_Invalid() throws Throwable {
	    String expected="Please fill the Applicant Name ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in First Name field$")
	public void user_does_not_enter_any_text_in_First_Name_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("");
		user.setSubmit();
		Thread.sleep(5000);
	}

	@Then("^First Name Field is Invalid$")
	public void first_Name_Field_is_Invalid() throws Throwable {
		String expected="Please fill the First Name ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Last Name field$")
	public void user_does_not_enter_any_text_in_Last_Name_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Last Name Field is Invalid$")
	public void last_Name_Field_is_Invalid() throws Throwable {
		String expected="Please fill the Last Name ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Father Name field$")
	public void user_does_not_enter_any_text_in_Father_Name_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Father Name Field is Invalid$")
	public void father_Name_Field_is_Invalid() throws Throwable {
		String expected="Please fill the Father Name ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Date of Birth field$")
	public void user_does_not_enter_any_text_in_Date_of_Birth_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Date of Birth Field is Invalid\\(Empty\\)$")
	public void date_of_Birth_Field_is_Invalid_Empty() throws Throwable {
		String expected="Please fill the DOB";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}


	@When("^User enters invalid text in Date of Birth field$")
	public void user_enters_invalid_text_in_Date_of_Birth_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10111994");
	    user.setSubmit();
	    Thread.sleep(5000);
	}
	
	@Then("^Date of Birth Field is Invalid\\(Invalid\\)$")
	public void date_of_Birth_Field_is_Invalid_Invalid() throws Throwable {
		String expected="Please Enter valid date(dd-MM-yyyy)";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does no selects Male or Female as Gender$")
	public void user_does_no_selects_Male_or_Female_as_Gender() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Gender Field is Invalid$")
	public void gender_Field_is_Invalid() throws Throwable {
		String expected="Please select the Gender";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Mobile Number field$")
	public void user_does_not_enter_any_text_in_Mobile_Number_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Mobile Number Field is Invalid\\(Empty\\)$")
	public void mobile_Number_Field_is_Invalid_Empty() throws Throwable {
		String expected="Please fill Mobile no";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}


	@When("^User enters invalid text in Mobile Number field$")
	public void user_enters_invalid_text_in_Mobile_Number_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("98564");
	    user.setSubmit();
	    Thread.sleep(5000);
	}
	
	@Then("^Mobile Number Field is Invalid\\(Invalid\\)$")
	public void mobile_Number_Field_is_Invalid_Invalid() throws Throwable {
		String expected="Please enter valid mobile no";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Email ID field$")
	public void user_does_not_enter_any_text_in_Email_ID_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("9745698547");
		user.setEmail("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Email Field is Invalid$")
	public void email_Field_is_Invalid() throws Throwable {
		String expected="Please fill the Email id ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User enters invalid text in Email ID field$")
	public void user_enters_invalid_text_in_Email_ID_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("8745698547");
		user.setEmail("example");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Email ID Field is Invalid$")
	public void email_ID_Field_is_Invalid() throws Throwable {
		String expected="Please enter valid Email id";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Landline Number field$")
	public void user_does_not_enter_any_text_in_Landline_Number_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("8745698547");
		user.setEmail("example@gmail.com");
		user.setLandLine("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Landline Number Field is Invalid$")
	public void landline_Number_Field_is_Invalid() throws Throwable {
		String expected="please fill the landline no";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not selects Office or Residence as Type Of Communication$")
	public void user_does_not_selects_Office_or_Residence_as_Type_Of_Communication() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("8745698547");
		user.setEmail("example@gmail.com");
		user.setLandLine("9856487541");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Type Of Communication Field is Invalid$")
	public void type_Of_Communication_Field_is_Invalid() throws Throwable {
		String expected="Please select the Type of Communication ";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Residential Address field$")
	public void user_does_not_enter_any_text_in_Residential_Address_field() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("8745698547");
		user.setEmail("example@gmail.com");
		user.setLandLine("9856487541");
		user.setResAddress();
		user.setResOffice();
		user.setResidenceAddress("");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Residential Address Field is Invalid$")
	public void residential_Address_Field_is_Invalid() throws Throwable {
		String expected="please enter the Addresss";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}
	@When("^User clicks on Submit with Valid User Details$")
	public void user_clicks_on_Submit_with_Valid_User_Details() throws Throwable {
		user.setName("Subhanshu");
		user.setFirstName("Subhanshu");
		user.setLastName("Bigasia");
		user.setFatherName("Bill Gates");
		user.setDOB("10-11-1994");
		user.setMale();
		user.setFemale();
		user.setMobileNo("8745698547");
		user.setEmail("example@gmail.com");
		user.setLandLine("9856487541");
		user.setResAddress();
		user.setResOffice();
		user.setResidenceAddress("Pune");
	    user.setSubmit();
	    Thread.sleep(5000);
	}

	@Then("^Form is submitted$")
	public void form_is_submitted() throws Throwable {
		String expected="Personal details are validated.";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	    
	}

}
