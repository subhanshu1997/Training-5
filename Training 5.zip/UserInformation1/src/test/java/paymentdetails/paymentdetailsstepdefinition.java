package paymentdetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.Payment;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class paymentdetailsstepdefinition {
	WebDriver driver;
	private Payment payment;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
		
	}
	
	@Given("^User is on paymentdetailspage$")
	public void user_is_on_paymentdetailspage() throws Throwable {
	    driver.get("D:\\Subhanshu\\Spring Boot Sps 3.9\\UserInformation1\\HTMl Files\\PaymentDetails.html");
	    payment=new Payment(driver);
	}

	@When("^User does not enter any text in Card holder name Field$")
	public void user_does_not_enter_any_text_in_Card_holder_name_Field() throws Throwable {
	    payment.setCardholdername("");
	    payment.setButton();
	    Thread.sleep(5000);
	}

	@Then("^Card Holder name Field is invalid$")
	public void card_Holder_name_Field_is_invalid() throws Throwable {
	    String expected="Please fill the Card holder name";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    Thread.sleep(5000);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Debit Card Number Field$")
	public void user_does_not_enter_any_text_in_Debit_Card_Number_Field() throws Throwable {
		System.out.println("Hello");
	    payment.setCardholdername("Subhanshu");
	    payment.setDebit("");
	    payment.setButton();
	    Thread.sleep(5000);
	    
	}

	@Then("^Debit Card Number Field is invalid$")
	public void debit_Card_Number_Field_is_invalid() throws Throwable {
		String expected="Please fill the Debit card Number";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in CVV Field$")
	public void user_does_not_enter_any_text_in_CVV_Field() throws Throwable {
		 payment.setCardholdername("Subhanshu");
		    payment.setDebit("5465465123654789");
		    payment.setCvv("");
		    payment.setButton();
		    Thread.sleep(5000);
	}

	@Then("^CVV Field is invalid$")
	public void cvv_Field_is_invalid() throws Throwable {
		String expected="Please fill the CVV";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Expiration month Field$")
	public void user_does_not_enter_any_text_in_Expiration_month_Field() throws Throwable {
		 payment.setCardholdername("Subhanshu");
		    payment.setDebit("5465465123654789");
		    payment.setCvv("564");
		    payment.setMonth("");
		    payment.setButton();
		    Thread.sleep(5000);
	}

	@Then("^Expiration month Field is invalid$")
	public void expiration_month_Field_is_invalid() throws Throwable {
		String expected="Please fill expiration month";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}

	@When("^User does not enter any text in Expiration Year Field$")
	public void user_does_not_enter_any_text_in_Expiration_Year_Field() throws Throwable {
		payment.setCardholdername("Subhanshu");
	    payment.setDebit("5465465123654789");
	    payment.setCvv("564");
	    payment.setMonth("05");
	    payment.setYear("");
	    payment.setButton();
	    Thread.sleep(5000);
	}

	@Then("^Expiration Year Field is invalid$")
	public void expiration_Year_Field_is_invalid() throws Throwable {
		String expected="Please fill the expiration year";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expected, actual);
	    driver.switchTo().alert().accept();
	}
	@When("^User clicks on Submit button with valid details$")
	public void user_clicks_on_Submit_button_with_valid_details() throws Throwable {
		payment.setCardholdername("Subhanshu");
	    payment.setDebit("5465465123654789");
	    payment.setCvv("564");
	    payment.setMonth("05");
	    payment.setYear("2022");
	    payment.setButton();
	    Thread.sleep(2000);
	}

	@Then("^Pan Card Registration Done successfully !!! should be shown$")
	public void pan_Card_Registration_Done_successfully_should_be_shown() throws Throwable {
	    
	}

}
