package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class User {
	WebDriver driver;

	@FindBy(id = "rdbCategory")
	@CacheLookup
	WebElement category;

	@FindBy(id = "txtName")
	@CacheLookup
	WebElement name;

	@FindBy(id = "txtFirstName")
	@CacheLookup
	WebElement firstName;

	@FindBy(id = "txtLastName")
	@CacheLookup
	WebElement lastName;

	@FindBy(id = "txtFatherName")
	@CacheLookup
	WebElement fatherName;

	@FindBy(id = "txtDOB")
	@CacheLookup
	WebElement DOB;

	@FindBy(id = "txtMobileNo")
	@CacheLookup
	WebElement mobileNo;

	@FindBy(id = "txtEmail")
	@CacheLookup
	WebElement email;

	@FindBy(id = "txtLndLine")
	@CacheLookup
	WebElement landLine;

	@FindBy(id = "rdbResAddress")
	@CacheLookup
	WebElement resAddress;

	@FindBy(id = "rdbOfficeAdd")
	@CacheLookup
	WebElement resOffice;

	@FindBy(id = "txtAResidenceAdd")
	@CacheLookup
	WebElement ResidenceAddress;

	@FindBy(id = "rdbMale")
	@CacheLookup
	WebElement Male;

	@FindBy(id = "rdbFemale")
	@CacheLookup
	WebElement Female;
	
	@FindBy(id="btnSubmit")
	@CacheLookup
	WebElement Submit;
	
	@FindBy(id="btnReset")
	@CacheLookup
	WebElement Reset;

	public User(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB.sendKeys(dOB);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getLandLine() {
		return landLine;
	}

	public void setLandLine(String landLine) {
		this.landLine.sendKeys(landLine);
	}

	public WebElement getResAddress() {
		return resAddress;
	}

	public void setResAddress() {
		this.resAddress.click();
	}

	public WebElement getResOffice() {
		return resOffice;
	}

	public void setResOffice() {
		this.resOffice.click();
	}

	public WebElement getResidenceAddress() {
		return ResidenceAddress;
	}

	public void setResidenceAddress(String residenceAddress) {
		this.ResidenceAddress.sendKeys(residenceAddress);
	}

	public WebElement getMale() {
		return Male;
	}

	public void setMale() {
		this.Male.click();
	}

	public WebElement getFemale() {
		return Female;
	}

	public void setFemale() {
		this.Female.click();
	}

	public WebElement getSubmit() {
		return Submit;
	}

	public void setSubmit() {
		this.Submit.click();
	}

	public WebElement getReset() {
		return Reset;
	}

	public void setReset() {
		this.Reset.click();
	}
	
	

}
