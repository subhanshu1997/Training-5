package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is on home page$")
	public void user_is_on_home_page() throws Throwable {
	    System.out.println("User is on HomePage");
	}

	@When("^HomePage opens$")
	public void homepage_opens() throws Throwable {
	   System.out.println("HomePage opens");
	}

	@Then("^Hello should be displayed as HyperText$")
	public void hello_should_be_displayed_as_HyperText() throws Throwable {
	    System.out.println("Hello is displayed");
	}

}
