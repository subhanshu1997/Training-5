package stepDefinition;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/hello"},glue= {"stepDefinition"},plugin="pretty")
public class TestRunner {
	public static void main(String[] args) {
	String exePath="D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver",exePath);
	WebDriver driver=new ChromeDriver();
	driver.get("file:///D:\\Subhanshu\\Spring Boot Sps 3.9\\Hello\\HTMl Files\\hello.html");
	WebElement element=driver.findElement(By.id("uName"));
	element.sendKeys("Subhanshu");
	
}
	

}
