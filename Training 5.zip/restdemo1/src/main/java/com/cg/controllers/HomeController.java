package com.cg.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Message;

@RestController
@RequestMapping("/test")
public class HomeController {
	// Process GET request localhost:5000/test/
	@GetMapping(value="/",produces= {"application/xml","application/json"})
	public Message testGet() {
		return new Message("This is GET Request");
	}

	@PostMapping(value="/",produces= {"application/xml","application/json"})
	public Message testPost() {
		return new Message("This is POST Request");
	}

	@PutMapping(value="/",produces= {"application/xml","application/json"})
	public String testPut() {
		return "This is PUT Request";
	}

	@DeleteMapping(value="/",produces= {"application/xml","application/json"})
	public String testDelete() {
		return "This is DELETE Request";
	}

}
/*
 * JSON application/json XML application/xml HTML application/html Plain text
 * application/text
 */
