package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is on HomePage$")
	public void user_is_on_HomePage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User is on HomePage");
	}

	@When("^User click on \"([^\"]*)\"$")
	public void user_click_on(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User clicks on Show alert box"+arg1);
	}

	@Then("^Alert box should popup showing \"([^\"]*)\"$")
	public void alert_box_should_popup_showing(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Alert box is shown");
	}


}
