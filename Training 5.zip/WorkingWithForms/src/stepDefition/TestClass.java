package stepDefition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is on User Registration Page$")
	public void user_is_on_User_Registration_Page() throws Throwable {
	    
	}

	@When("^User enters an alphanumeric word in \"([^\"]*)\" field and \"([^\"]*)\" field is not blank$")
	public void user_enters_an_alphanumeric_word_in_field_and_field_is_not_blank(String arg1, String arg2) throws Throwable {
	   
	}


	@When("^User enters an alphanumeric word in \"([^\"]*)\" field and \"([^\"]*)\" field is not blank and \"([^\"]*)\" field matches with \"([^\"]*)\" field$")
	public void user_enters_an_alphanumeric_word_in_field_and_field_is_not_blank_and_field_matches_with_field(String arg1, String arg2, String arg3, String arg4) throws Throwable {
	    
	}

	@When("^User enters an alphabatical word in \"([^\"]*)\" field and \"([^\"]*)\" field is not blank and length of word enterd in \"([^\"]*)\" field is less than (\\d+)$")
	public void user_enters_an_alphabatical_word_in_field_and_field_is_not_blank_and_length_of_word_enterd_in_field_is_less_than(String arg1, String arg2, String arg3, int arg4) throws Throwable {
	    
	}

	@When("^User selects Male radio button$")
	public void user_selects_Male_radio_button() throws Throwable {
	
	}

	@Then("^Male should be send as \"([^\"]*)\" value$")
	public void male_should_be_send_as_value(String arg1) throws Throwable {
	    
	}

	@When("^User selects Female radio button$")
	public void user_selects_Female_radio_button() throws Throwable {
	    
	}

	@Then("^Female should be send as \"([^\"]*)\" value$")
	public void female_should_be_send_as_value(String arg1) throws Throwable {
	    
	}

	@When("^User selects Date Of Birth from Date Selector Componenent$")
	public void user_selects_Date_Of_Birth_from_Date_Selector_Componenent() throws Throwable {
	    
	}

	@Then("^The \"([^\"]*)\" field is valid$")
	public void the_field_is_valid(String arg1) throws Throwable {
	    
	}

	@When("^User enters a word similar to \"([^\"]*)\" in \"([^\"]*)\" field and \"([^\"]*)\" field is not blank$")
	public void user_enters_a_word_similar_to_in_field_and_field_is_not_blank(String arg1, String arg2, String arg3) throws Throwable {
	   
	}

	@Then("^The \"([^\"]*)\" field is Valid$")
	public void the_field_is_Valid(String arg1) throws Throwable {
	   
	}

	@When("^User enters an alphabatical word in \"([^\"]*)\" field and \"([^\"]*)\"First Name\" field is less than (\\d+)$")
	public void user_enters_an_alphabatical_word_in_field_and_First_Name_field_is_less_than(String arg1, String arg2, int arg3) throws Throwable {
	    
	}

	@When("^User selects Mumbai$")
	public void user_selects_Mumbai() throws Throwable {
	    
	}

	@Then("^Mumbai should be send$")
	public void mumbai_should_be_send() throws Throwable {
	   
	}

	@When("^User selects Pune$")
	public void user_selects_Pune() throws Throwable {
	    
	}

	@Then("^Pune should be send$")
	public void pune_should_be_send() throws Throwable {
	    
	}

	@When("^User selects Bangalore$")
	public void user_selects_Bangalore() throws Throwable {
	    
	}

	@Then("^Bangalore should be send$")
	public void bangalore_should_be_send() throws Throwable {
	   
	}

	@When("^User selects Chennai$")
	public void user_selects_Chennai() throws Throwable {
	   
	}

	@Then("^Chennai should be send$")
	public void chennai_should_be_send() throws Throwable {
	    
	}

	@When("^A (\\d+) digit number is entered in \"([^\"]*)\" field and \"([^\"]*)\" field is not empty$")
	public void a_digit_number_is_entered_in_field_and_field_is_not_empty(int arg1, String arg2, String arg3) throws Throwable {
	   
	}

	@When("^User clicks on \"([^\"]*)\" button$")
	public void user_clicks_on_button(String arg1) throws Throwable {
	    
	}

	@Then("^Form should be submitted with valid inputs$")
	public void form_should_be_submitted_with_valid_inputs() throws Throwable {
	    
	}

	@Then("^All fields in forms should be set to blank$")
	public void all_fields_in_forms_should_be_set_to_blank() throws Throwable {
	}
	

}
