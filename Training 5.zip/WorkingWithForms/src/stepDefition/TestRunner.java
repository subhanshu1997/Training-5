package stepDefition;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/forms"},glue= {"stepDefinition"},plugin="pretty")
public class TestRunner {
	public static void main(String[] args) {
		String exePath="D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",exePath);
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D:\\Subhanshu\\Spring Boot Sps 3.9\\WorkingWithForms\\HTML Files\\WorkingWithForms.html");
		WebElement element1=driver.findElement(By.id("txtUserName"));
		element1.sendKeys("subhanshu");
		element1=driver.findElement(By.id("txtPassword"));
		element1.sendKeys("subhanshu1997");
		element1=driver.findElement(By.id("txtConfPassword"));
		element1.sendKeys("subhanshu1997");
		element1=driver.findElement(By.id("txtFirstName"));
		element1.sendKeys("Subhanshu");
		element1=driver.findElement(By.id("txtLastName"));
		element1.sendKeys("Bigasia");
		element1=driver.findElement(By.id("txtEmail"));
		element1.sendKeys("subhanshu@domain.com");
		element1=driver.findElement(By.id("txtAddress"));
		element1.sendKeys("Pune");
		element1=driver.findElement(By.id("txtPhone"));
		element1.sendKeys("8975648752");
		
		
	}

}
