package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is on HomePage$")
	public void user_is_on_HomePage() throws Throwable {
	    System.out.println("User is on HomePage");
	}

	@When("^User clicks on \"([^\"]*)\" button$")
	public void user_clicks_on_button(String arg1) throws Throwable {
	    System.out.println("User clicks on 'Open window' button");
	}

	@Then("^New window should be opened on which User is redirected to \"([^\"]*)\"$")
	public void new_window_should_be_opened_on_which_User_is_redirected_to(String arg1) throws Throwable {
	    System.out.println("New Window is Opened");
	}

}
