package com.cg.bean;

public class Transaction {
private Long mobileno;
private Double amount;
public Long getMobileno() {
	return mobileno;
}
public void setMobileno(Long mobileno) {
	this.mobileno = mobileno;
}
public Double getAmount() {
	return amount;
}
public void setAmount(Double amount) {
	this.amount = amount;
}
public Transaction(Long mobileno, Double amount) {
	super();
	this.mobileno = mobileno;
	this.amount = amount;
}
public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}

}
