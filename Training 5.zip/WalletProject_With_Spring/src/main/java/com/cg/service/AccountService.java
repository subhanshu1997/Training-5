package com.cg.service;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dao.*;
import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.bean.Transfer;
@Service
public class AccountService implements AccountOperation{
	@Autowired
	private AccountDAO dao;
	
	@Override
	@Transactional
	public boolean withdraw(Transaction transaction) {
		Account account=this.findAccount(transaction.getMobileno());
		if(account==null) {
			System.out.println("No account with given mobile number exist");
			return false;
		}
		if(transaction.getAmount()<0) {
			return false;
		}
		Double new_balance=account.getBalance()-transaction.getAmount();
		if(new_balance<0) {
			System.out.println("Insufficient Balance");
			return false;
		}
		account.setBalance(new_balance);
		return true;
	}

	@Override
	@Transactional
	public boolean deposit(Transaction transaction) {
		Account account=this.findAccount(transaction.getMobileno());
		if(account==null) {
			System.out.println("No account with given mobile number exist");
			return false;
		}
		if(transaction.getAmount()<0) {
			return false;
		}
		Double new_balance=account.getBalance()+transaction.getAmount();
		account.setBalance(new_balance);
		return true;
	}

	@Override
	@Transactional
	public boolean transfer(Transfer transfer) {
		Account a1=this.findAccount(transfer.getFrom());
		Account a2=this.findAccount(transfer.getTo());
		if(a1==null || a2==null) {
			System.out.println("One or more account donot exist");
			return false;
		}
		Double a1_new_balance=a1.getBalance()-transfer.getAmount();
		if(a1_new_balance<0) {
			System.out.println("Insufficient balance");
			return false;
		}
		if(transfer.getAmount()<0) {
			return false;
		}
		a1.setBalance(a1_new_balance);
		a2.setBalance(a2.getBalance()+transfer.getAmount());
		return true;
	}

	@Override
	@Transactional
	public boolean addAccount(Account ob) {
		Account account=this.findAccount(ob.getMobile());
		System.out.println(account);
		if(account!=null) {
			System.out.println("Account Exist");
			return false;
		}
		if(ob.getBalance()<0) {
			return false;
		}
		dao.save(ob);
		return true;
	}

	@Override
	@Transactional
	public boolean deleteAccount(Long mob) {
		Account account=this.findAccount(mob);
		if(account==null) {
			System.out.println("No account exist with given id");
			return false;
		}
		dao.delete(account);
		return true;
	}

	@Override
	@Transactional
	public Account findAccount(Long mobileno) {
		Optional<Account> account=dao.findById(mobileno);
		System.out.println(account);
		if(!account.isPresent())
			return null;
		return account.get();
	}

	@Override
	@Transactional
	public List<Account> getAll() {
		List<Account> list=dao.findAll();
		if(list.isEmpty()) {
			return null;
		}
		return list;
	}

	@Override
	@Transactional
	public boolean updateAccount(Account ob, Long mob) {
		Account account=this.findAccount(mob);
		if(account==null) {
			System.out.println("No account with given mobile number exist");
			return false;
		}
		if(ob.getBalance()<0) {
			return false;
		}
		account.setAccountholder(ob.getAccountholder());
		account.setAid(ob.getAid());
		account.setBalance(ob.getBalance());
		account.setMobile(ob.getMobile());
		return true;
	}
	
}