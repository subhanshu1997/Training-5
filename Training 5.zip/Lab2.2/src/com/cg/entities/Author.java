package com.cg.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="author5")
public class Author {
	@Id
	Integer ID;
	@Column
	String name;
	@ManyToMany(targetEntity=Book.class)
	@JoinColumn(name="ISBN")
	List<Book> books;

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Author(Integer iD, String name, List<Book> books) {
		super();
		ID = iD;
		this.name = name;
		this.books = books;
	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Author [ID=" + ID + ", name=" + name + ", books=" + books + "]";
	}
}
