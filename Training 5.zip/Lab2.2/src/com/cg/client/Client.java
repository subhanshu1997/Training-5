package com.cg.client;

import com.cg.services.BookService;
import com.cg.services.BookServiceImpl;

public class Client {

	public static void main(String[] args) {
		BookService service=new BookServiceImpl();
//		Populating Table
		service.populate();
		//Getting author by id
		System.out.println(service.getAuthorById(10));
		//Getting books by range
		System.out.println(service.getBooksByRange());
		//Getting books by author
		System.out.println(service.getBooksByAuthor("james"));

	}

}
