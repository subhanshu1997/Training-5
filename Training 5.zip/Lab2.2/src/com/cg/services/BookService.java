package com.cg.services;

import java.util.List;

import com.cg.entities.Author;
import com.cg.entities.Book;

public interface BookService {
	public void populate();
	public List<Book> getBooksByAuthor(String author);
	public List<Book> getBooksByRange();
	public Author getAuthorById(Integer id);
		
}
