package com.cg.services;

import java.util.List;

import com.cg.daos.BookDAO;
import com.cg.daos.BookDAOImpl;
import com.cg.entities.Author;
import com.cg.entities.Book;

public class BookServiceImpl implements BookService{
	BookDAO dao=new BookDAOImpl();
	@Override
	public void populate() {
		dao.populate();
		
	}

	@Override
	public List<Book> getBooksByAuthor(String author) {
		return dao.getBooksByAuthor(author);
	}

	@Override
	public List<Book> getBooksByRange() {
		return dao.getBooksByRange();
	}

	@Override
	public Author getAuthorById(Integer id) {
		return dao.getAuthorById(id); 
	}

}
