package com.cg.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


import com.cg.entities.Author;
import com.cg.entities.Book;


public class BookDAOImpl implements BookDAO{
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=factory.createEntityManager();
	@Override
	public void populate() {
		em.getTransaction().begin();
		List<Book> books=new ArrayList<Book>();
		Book b1 = new Book(1001,"Harry Potter 1",600, null);
		Book b2 = new Book(1002,"Harry Potter 2",200, null);
		em.persist(b1);
		em.persist(b2);
		em.getTransaction().commit();
		books.add(b1);
		books.add(b2);
		Author a1 = new Author(10, "james", books);
		Author a2 = new Author(20, "carter", books);
		em.getTransaction().begin();
		em.persist(a1);
		em.persist(a2);
		em.getTransaction().commit();	
	}

	@Override
	public List<Book> getBooksByAuthor(String author) {
		em.getTransaction().begin();
		Query query=em.createQuery("select e from Author e where e.name="+"'"+author+"'");
		em.getTransaction().commit();
		return query.getResultList();
	}

	@Override
	public List<Book> getBooksByRange() {
		em.getTransaction().begin();
		Query query=em.createQuery("select e from Book e where e.price>500 and e.price<1000");
		em.getTransaction().commit();
//		List<Book> list=query.getResultList();
//		for(Object b:list) {
//			System.out.println(b.toString());
//		}
		return query.getResultList();
	}

	@Override
	public Author getAuthorById(Integer id) {
		em.getTransaction().begin();
		Author author= em.find(Author.class,id);
		em.getTransaction().commit();
		return author;
	}

}
