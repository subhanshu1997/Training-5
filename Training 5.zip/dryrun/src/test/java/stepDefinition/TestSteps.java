package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
	   int i=0;
	   while(i++<10000);
	}

	@When("^User Navigat to Login Page$")
	public void user_Navigat_to_Login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int i=0;
		   while(i++<10000);
	}

	@When("^User enters UserName and Password$")
	public void user_enters_UserName_and_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int i=0;
		   while(i++<10000);
	}

	@Then("^Message displayed Lofin Successfully$")
	public void message_displayed_Lofin_Successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int i=0;
		   while(i++<10000);
	}

	@When("^User LogOut from the Application$")
	public void user_LogOut_from_the_Application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int i=0;
		   while(i++<10000);
	}

	@Then("^Message displayed LogOut Successfully$")
	public void message_displayed_LogOut_Successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		int i=0;
		   while(i++<10000);
	}



}
