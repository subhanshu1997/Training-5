package com.cg.exception;
//Throwing Exception
public class ApplicationException extends RuntimeException{
	public ApplicationException(String message) {
		super(message);
	}
	
}
