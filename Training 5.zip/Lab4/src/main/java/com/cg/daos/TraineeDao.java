package com.cg.daos;

import java.util.List;

import com.cg.entities.Trainee;

public interface TraineeDao {
	public boolean addTrainee(Trainee t);
	public List<Trainee> fillDeleteTrainee(Integer traineeId);
	public void deleteTrainee(Integer traineeId);
	public List<Trainee> getAllTrainee();
	public List<Trainee> retrieveTrainee(Integer traineeId);
	public void modifyTrainee(Integer traineeId,Integer updatedTraineeId,String updatedTraineeName,String updatedTraineeLocation,String updatedTraineeDomain);
}
