package com.cg.daos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;
import com.cg.exception.ApplicationException;

@Repository
public class TraineeDaoImpl implements TraineeDao{
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em=emf.createEntityManager();
	public boolean addTrainee(Trainee t) {
		if(this.retrieveTrainee(t.getTraineeId())!=null) {
			return false;
		}
		else {
		System.out.println("Added");
		em.getTransaction().begin();
		em.persist(t);
		em.flush();
		System.out.println("Record added : ");
		em.getTransaction().commit();
		return true;
		}
	}

	public List<Trainee> fillDeleteTrainee(Integer traineeId) {
		if(this.retrieveTrainee(traineeId)==null) {
			return null;
		}
		else {
		em.getTransaction().begin();
		List<Trainee> l=new ArrayList<Trainee>();
		l.add(em.find(Trainee.class,traineeId));
		em.flush();
		em.getTransaction().commit();
		return l;}
	}
	public void deleteTrainee(Integer traineeId) {
		em.getTransaction().begin();
		em.remove(em.find(Trainee.class,traineeId));
		em.flush();
		em.getTransaction().commit();
	}
	public List<Trainee> retrieveTrainee(Integer traineeId){
		em.getTransaction().begin();
		List<Trainee> l=new ArrayList<Trainee>();
		l.add(em.find(Trainee.class,traineeId));
		em.flush();
		em.getTransaction().commit();
		if(l.get(0)==null) {
			return null;
		}
		return l;
	}
	public List<Trainee> getAllTrainee(){
		em.getTransaction().begin();
		Query query=em.createQuery("select a from Trainee a");
		em.flush();
		em.getTransaction().commit();
		if(query.getResultList().isEmpty()) {
			return null;
		}
		return query.getResultList();
		
	}
	public void modifyTrainee(Integer traineeId,Integer updatedTraineeId,String updatedTraineeName,String updatedTraineeLocation,String updatedTraineeDomain) {
		em.getTransaction().begin();
		Trainee t=em.find(Trainee.class,traineeId);
		t.setTraineeId(updatedTraineeId);
		t.setTraineeDomain(updatedTraineeDomain);
		t.setTraineeLocation(updatedTraineeLocation);
		t.setTrainerrName(updatedTraineeName);
		em.flush();
		em.getTransaction().commit();
		this.deleteTrainee(traineeId);
		this.addTrainee(t);		
	}

}
