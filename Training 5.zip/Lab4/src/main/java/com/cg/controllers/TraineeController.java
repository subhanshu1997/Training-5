package com.cg.controllers;

import java.util.List;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.entities.Trainee;
import com.cg.services.TraineeService;
import com.cg.services.TraineeServiceImpl;

@Controller
public class TraineeController {
	private TraineeService service=new TraineeServiceImpl();
	@GetMapping("/")
	public String showLogin() {
		return "login";
	}
	@PostMapping("/login")
	public String login(Model model,@RequestParam("username")String username,@RequestParam("password")String password) {
		if(username.equals("admin") && password.equals("admin123")) {
			return "home";
		}
		else {
			model.addAttribute("invalid","Invalid username or password");
			return "login";
		}
	}
	@GetMapping("/showAddTrainee")
	public String showAddTrainee() {
		return "addtrainee";
	}
	@GetMapping("/showDeleteTrainee")
	public String showDeleteTrainee() {
		return "deletetrainee";
	}
	@GetMapping("/showModifyTrainee")
	public String showModifyTrainee() {
		return "modifytrainee";
	}
	@GetMapping("/showRetreiveTrainee")
	public String showRetreiveTrainee() {
		return "retreivetrainee";
	}
	@GetMapping("/showRetreiveAllTrainee")
	public String showRetreiveAllTrainee(Model model) {
		if(service.getAllTrainee()==null) {
			model.addAttribute("message","No trainee exist in database");
			return "home";
		}
		model.addAttribute("trainee",service.getAllTrainee());
		return "retreivealltrainee";
	}
	@PostMapping("/addTrainee")
	public String addTrainee(Model model,@RequestParam("traineeId") Integer traineeId,@RequestParam("traineeName") String traineeName,
			@RequestParam("radio") String traineeLocation,@RequestParam ("traineeDomain") String traineeDomain) {
		Trainee t=new Trainee(traineeId,traineeName,traineeDomain,traineeLocation);
		boolean flag=service.addTrainee(t);
		if(flag==true) {
		model.addAttribute("message","Trainee Added");
		return "home";
		}
		else {
		model.addAttribute("message","Trainee with the same ID Exist");
		return "home";}
	}
	Integer traineeId=0;	
	@PostMapping("/fillDeleteTrainee")
	public String fillDeleteTrainee(Model model,@RequestParam("traineeId") Integer traineeId) {
		this.traineeId=traineeId;
		List<Trainee> t=service.fillDeleteTrainee(traineeId);
		if(t==null) {
			model.addAttribute("message","No Trainee with the given id exist");
		return "home";	
		}
		model.addAttribute("trainee",t);
		return "deletetrainee";
	}
	@PostMapping("/retreiveTrainee")
	public String retreiveTrainee(Model model,@RequestParam("traineeId") Integer traineeId) {
		this.traineeId=traineeId;
		List<Trainee> t=service.retrieveTrainee(traineeId);
		if(t==null) {
			model.addAttribute("message","No Trainee with the given id exist");
			return "home";
		}
		model.addAttribute("trainee",t);
		return "retreivetrainee";
	}
	@PostMapping("/fillModifyTrainee")
	public String fillModifyTrainee(Model model,@RequestParam("traineeId") Integer traineeId) {
		this.traineeId=traineeId;
		List<Trainee> t=service.retrieveTrainee(traineeId);
		if(t==null) {
			model.addAttribute("message","No Trainee with the given id exist");
			return "home";
		}
		model.addAttribute("trainee",t);
		return "modifytrainee";
	}
	@PostMapping("/ModifyTrainee")
	public String modifyTrainee(Model model,@RequestParam("updatedTraineeId") Integer updatedTraineeId,
			@RequestParam("updatedTraineeName") String updatedTraineeName,@RequestParam("updatedTraineeLocation")String updatedTraineeLocation,
			@RequestParam("updatedTraineeDomain") String updatedTraineeDomain){
		service.modifyTrainee(traineeId,updatedTraineeId,updatedTraineeName,updatedTraineeLocation,updatedTraineeDomain);
		model.addAttribute("message","Trainee modified");
		return "home";
	}
	
	
	@PostMapping("/DeleteTrainee")
	public String deleteTrainee(Model model) {
		service.deleteTrainee(traineeId);
		model.addAttribute("message","Trainee Deleted");
		return "home";
	}

}
