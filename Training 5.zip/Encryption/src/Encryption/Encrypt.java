package Encryption;

public class Encrypt {
	public static void main(String[] args) {
		final String secretKey="SomeSecretKey";
		String originalString="UcOLDZV0dueVWN/K019ATA==";
//		String encrypt=new Encryption().encrypt(originalString,secretKey);
		String decrypt=new Encryption().decrypt(originalString,secretKey);
//		System.out.println(encrypt);
		System.out.println(decrypt);
	}

}
