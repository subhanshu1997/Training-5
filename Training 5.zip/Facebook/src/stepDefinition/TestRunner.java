package stepDefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/login1"},glue= {"stepdefinition"},dryRun=true,plugin= {"pretty"})
public class TestRunner {

}
