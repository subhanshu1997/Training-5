package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@When("^User enters his/her Subhanshu and subbu(\\d+)$")
	public void user_enters_his_her_Subhanshu_and_subbu(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@Then("^User should see Logged In$")
	public void user_should_see_Logged_In() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@When("^User enters his/her (\\d+) and subbu(\\d+)$")
	public void user_enters_his_her_and_subbu(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@Then("^User should see LoggedIn$")
	public void user_should_see_LoggedIn() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}
	

}
