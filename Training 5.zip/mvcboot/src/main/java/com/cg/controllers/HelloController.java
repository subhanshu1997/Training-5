package com.cg.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Product;
@RestController
public class HelloController {
	@GetMapping("/")
	public String hello() {
		return "Hello World";
	}
	@GetMapping("/products")
	public List<Product> getProducts(){
		List<Product> list=new ArrayList<Product>();
		list.add(new Product(505,"Oracle","No",50000.00));
		list.add(new Product(505,"Microsoft","Yes",10000.00));
		list.add(new Product(505,"MySQL","No",420000.00));
		list.add(new Product(505,"MondoDB","Yes",98000.00));
		return list;
	}
}
