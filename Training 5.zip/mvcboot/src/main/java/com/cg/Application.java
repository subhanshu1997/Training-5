package com.cg;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@XmlRootElement
public class Application {

	public static void main(String[] args) {
		/*This single line does following:
		 * 	1. Create AnnotationConfigApplicationContext
		 * 	2. It uses @ComponentScan for all child packages
		 * 		2.1 It picks up HelloController class
		 * 		2.2 Does request mapping to "/"
		 *	3. It reads application.properties
		 * 		3.1 Found one property "server.port=3000"
		 *	4. Launches Embedded Tomcat server and deploy HelloController
		 *	5.Wait for you to terminate the process
		 * */
		SpringApplication.run(Application.class,args);
		System.out.println("Listening to port at 3000");

	}

}
