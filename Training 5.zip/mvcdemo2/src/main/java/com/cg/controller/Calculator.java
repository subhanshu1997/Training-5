package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Calculator {
	@RequestMapping(value = "/cal", method = RequestMethod.POST)
	public String calculate(Model model, @RequestParam("p") double p,
			@RequestParam("r") double r, @RequestParam("t") int t) {
		model.addAttribute("result", (p * r * t) / 100);
		return "home";
	}
}
