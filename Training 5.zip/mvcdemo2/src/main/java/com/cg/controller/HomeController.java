package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HomeController {
	@GetMapping
	public String home(Model model) {
		// Request Handling Method
		// Syntax:
		// 1.public ModelAndView methodName(){}
		// 2.public String methodName(Model model){}
		// 3.public String methodName(Map<String,Onject> model){}
		// 4.public String methodName(){}
		model.addAttribute("msg", "Welcome to MVC");
		return "home";
	}
}
