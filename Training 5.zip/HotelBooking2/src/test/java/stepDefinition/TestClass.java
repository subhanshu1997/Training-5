package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bookBean.Book;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	WebDriver driver;
	Book book;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();	
	}
	
	
	@Given("^User is on login Page$")
	public void user_is_on_login_Page() throws Throwable {
	    driver.get("D:\\Subhanshu\\Spring Boot Sps 3.9\\HotelBooking\\HTML Files\\login.html");
	}

	@When("^User provides Invalid Username$")
	public void user_provides_Invalid_Username() throws Throwable {
	    book.setUserName("");
	    book.setBtnLogin();
	    Thread.sleep(2000);
	}

	@Then("^The User Name field is invalid$")
	public void the_User_Name_field_is_invalid() throws Throwable {
	   
	}

	@When("^User provides Invalid Password$")
	public void user_provides_Invalid_Password() throws Throwable {
	    book.setUserName("Capgemini");
	    book.setUserPwd("");
	    book.setBtnLogin();
	    Thread.sleep(2000);
	}

	@Then("^The Password field is invalid$")
	public void the_Password_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid Username and Password$")
	public void user_enters_valid_Username_and_Password() throws Throwable {
		book.setUserName("Yogini");
	    book.setUserPwd("Yogini");
	    book.setBtnLogin();
	    Thread.sleep(2000);
	}

	@Then("^User is redirected to Hotel Booking Page$")
	public void user_is_redirected_to_Hotel_Booking_Page() throws Throwable {
	}

	@Given("^User is on Hotel Booking Page$")
	public void user_is_on_Hotel_Booking_Page() throws Throwable {
	}

	@When("^User enters invalid data in First Name field$")
	public void user_enters_invalid_data_in_First_Name_field() throws Throwable {
	    book.setTxtFN("");
	    book.setBtnPayment();
	    Thread.sleep(2000);
	}

	@Then("^The First Name field is invalid$")
	public void the_First_Name_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name but invalid data in Last Name field$")
	public void user_enters_valid_data_in_First_Name_but_invalid_data_in_Last_Name_field() throws Throwable {
		 book.setTxtFN("Subhanshu");
		 book.setTxtLN("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Last Name field is invalid$")
	public void the_Last_Name_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name and Last Name field but invalid data in Email Id field$")
	public void user_enters_valid_data_in_First_Name_and_Last_Name_field_but_invalid_data_in_Email_Id_field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Email Id field is invalid$")
	public void the_Email_Id_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name and Email Id field but invalid data in Mobile No\\. field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_and_Email_Id_field_but_invalid_data_in_Mobile_No_field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Mobile No\\. field is invalid$")
	public void the_Mobile_No_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id and Mobile No\\. field but invalid data in Address field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_and_Mobile_No_field_but_invalid_data_in_Address_field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Address field is invalid$")
	public void the_Address_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\. and Address field but does not select anything from City dropdown$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_and_Address_field_but_does_not_select_anything_from_City_dropdown() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Select City");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The City field is invalid$")
	public void the_City_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address and City field but does not select anything from State dropdown$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_and_City_field_but_does_not_select_anything_from_State_dropdown() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The State field is invalid$")
	public void the_State_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City and State field and selects Number from Number of Guest Staying Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_and_State_field_and_selects_Number_from_Number_of_Guest_Staying_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^Number of people attending should be displayed$")
	public void number_of_people_attending_should_be_displayed() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City and State field but does not enter valid data in Card Holder Name Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_and_State_field_but_does_not_enter_valid_data_in_Card_Holder_Name_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Card Holder Name field is invalid$")
	public void the_Card_Holder_Name_field_is_invalid() throws Throwable {
	    
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City,State and Card Holder Name field but does not enter valid data in Debit Card Number Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_State_and_Card_Holder_Name_field_but_does_not_enter_valid_data_in_Debit_Card_Number_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("Subhanshu");
		 book.setDebit("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Debit Card Number field is invalid$")
	public void the_Debit_Card_Number_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City,State,Card Holder Name and Debit card Number field but does not enter valid data in CVV Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_State_Card_Holder_Name_and_Debit_card_Number_field_but_does_not_enter_valid_data_in_CVV_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("Subhanshu");
		 book.setDebit("101");
		 book.setCvv("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The CVV field is invalid$")
	public void the_CVV_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City,State,Card Holder Name,Debit card Number and CVV field but does not enter valid data in Expiration Month Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_State_Card_Holder_Name_Debit_card_Number_and_CVV_field_but_does_not_enter_valid_data_in_Expiration_Month_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("Subhanshu");
		 book.setDebit("101");
		 book.setCvv("458");
		 book.setMonth("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Expiration Month field is invalid$")
	public void the_Expiration_Month_field_is_invalid() throws Throwable {
	}

	@When("^User enters valid data in First Name,Last Name,Email Id,Mobile No\\.,Address,City,State,Card Holder Name,Debit card Number,CVV and Expiration Month field but does not enter valid data in Expiration Year Field$")
	public void user_enters_valid_data_in_First_Name_Last_Name_Email_Id_Mobile_No_Address_City_State_Card_Holder_Name_Debit_card_Number_CVV_and_Expiration_Month_field_but_does_not_enter_valid_data_in_Expiration_Year_Field() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("Subhanshu");
		 book.setDebit("101");
		 book.setCvv("458");
		 book.setMonth("Feb");
		 book.setYear("");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^The Expiration Year field is invalid$")
	public void the_Expiration_Year_field_is_invalid() throws Throwable {
	}

	@When("^User clicks on Submit button with valid inputs$")
	public void user_clicks_on_Submit_button_with_valid_inputs() throws Throwable {
		book.setTxtFN("Subhanshu");
		 book.setTxtLN("Bigasia");
		 book.setEmail("example@domain.com");
		 book.setPhone("8745698532");
		 book.setAddress("Pune");
		 book.setCity("Pune");
		 book.setState("Select State");
		 book.setPersons("1");
		 book.setCardholdername("Subhanshu");
		 book.setDebit("101");
		 book.setCvv("458");
		 book.setMonth("Feb");
		 book.setYear("2019");
		 book.setBtnPayment();
		 Thread.sleep(2000);
	}

	@Then("^Redirected to Success Page$")
	public void redirected_to_Success_Page() throws Throwable {
	}

	@When("^User clicks on Reset button$")
	public void user_clicks_on_Reset_button() throws Throwable {
	}

	@Then("^All fields in forms should be set to blank$")
	public void all_fields_in_forms_should_be_set_to_blank() throws Throwable {
	}

}
