package bookBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Book {
WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement userPwd;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement txtFN;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement txtLN;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(name="persons")
	@CacheLookup
	WebElement persons;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardholdername;
	
	@FindBy(name="debit")
	@CacheLookup
	WebElement debit;
	
	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement month;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement year;
	
	@FindBy(id="btnPayment")
	WebElement btnPayment;
	
	@FindBy(id="btnLogin")
	WebElement btnLogin;
	
	public Book(WebDriver driver) {
		System.out.println("Hello");
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd.sendKeys(userPwd);
	}

	public WebElement getTxtFN() {
		return txtFN;
	}

	public void setTxtFN(String txtFN) {
		this.txtFN.sendKeys(txtFN);
	}

	public WebElement getTxtLN() {
		return txtLN;
	}

	public void setTxtLN(String txtLN) {
		this.txtLN.sendKeys(txtLN);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getPersons() {
		return persons;
	}

	public void setPersons(String persons) {
		this.persons.sendKeys(persons);
	}

	public WebElement getCardholdername() {
		return cardholdername;
	}

	public void setCardholdername(String cardholdername) {
		this.cardholdername.sendKeys(cardholdername);
	}

	public WebElement getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month.sendKeys(month);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	public WebElement getBtnPayment() {
		return btnPayment;
	}

	public void setBtnPayment() {
		this.btnPayment.click();
	}

	public WebElement getBtnLogin() {
		return btnLogin;
	}

	public void setBtnLogin() {
		this.btnLogin.click();;
	}

}
