package login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.Register;

public class LoginStepDefinition {
	WebDriver driver;
	private Register register;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	@Given("^User is on 'register' Page$")
	public void user_is_on_register_Page() throws Throwable {
	    driver.get("D:\\Users\\sbigasia\\Desktop\\register.html");
		register = new Register(driver);
	}

	@When("^user enters invalid Name$")
	public void user_enters_invalid_Name() throws Throwable {
	    register.setName("");
	    register.setRegisterButton();
	}

	@Then("^display 'Enter Student Name'$")
	public void display_Enter_Student_Name() throws Throwable {
	    System.out.println("Enter Student Name");
	}

	@When("^user enters valid name but invalid address$")
	public void user_enters_valid_name_but_invalid_address() throws Throwable {
	    register.setName("Subhanshu");
	    register.setAddress("");
	    register.setRegisterButton();
	}

	@Then("^display 'Please Enter Address'$")
	public void display_Please_Enter_Address() throws Throwable {
	    System.out.println("Please Enter Marks");
	}

	@When("^user enters valid name,address but invalid marks$")
	public void user_enters_valid_name_address_but_invalid_marks() throws Throwable {
		register.setName("Subhanshu");
	    register.setAddress("Pune");
	    register.setMarks("");
	    register.setRegisterButton();
	}

	@Then("^display 'Please Enter Marks'$")
	public void display_Please_Enter_Marks() throws Throwable {
	    System.out.println("Please Enter Marks");
	}

	@When("^user enters Name,Address and Marks$")
	public void user_enters_Name_Address_and_Marks() throws Throwable {
		register.setName("Subhanshu");
	    register.setAddress("");
	    register.setMarks("");
	    register.setRegisterButton();
	}

	@Then("^display 'Enter Valid Data'$")
	public void display_Enter_Valid_Data() throws Throwable {
	    System.out.println("Enter Valid Data");
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		register.setName("Subhanshu");
	    register.setAddress("pune");
	    register.setMarks("100");
	    register.setRegisterButton();
	}

	@Then("^display 'Success' Page$")
	public void display_Success_Page() throws Throwable {
	    driver.get("D:\\Users\\sbigasia\\Desktop\\success.html");
	}

}
