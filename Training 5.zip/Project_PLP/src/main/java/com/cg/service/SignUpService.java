package com.cg.service;

public interface SignUpService {

	boolean userExists(String emailId);
	
	
}
