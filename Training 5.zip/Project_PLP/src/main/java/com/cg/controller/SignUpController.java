package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.User1;
import com.cg.service.SignUpServiceImpl;


@RestController
@RequestMapping("/")
public class SignUpController {

	@Autowired
	private SignUpServiceImpl service;
	
	@PostMapping(value="/add",consumes={"application/json"})
	public ResponseEntity<String> addUser(@RequestBody User1 user) {
		if(service.userExists(user.getEmailid()))
			return new ResponseEntity<String>("User Already Exists",HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<String>("Product Not Created!!",HttpStatus.OK);
	}
}
