package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import labelBean.Label;

public class TestClass {
	WebDriver driver;
	private Label label;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\sbigasia\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();		
	}
	
	@Given("^User is on Print Label Page$")
	public void user_is_on_Print_Label_Page() throws Throwable {
		label=new Label(driver);
		driver.get("D:\\Subhanshu\\Spring Boot Sps 3.9\\Label\\HTML Files\\print.html");
		Thread.sleep(2000);
		label.setEquipment("101");
		label.setLocation("2050");
		label.setUser("0054");
		Thread.sleep(3000);
	}

	@When("^User clicks on print label with valid data$")
	public void user_clicks_on_print_label_with_valid_data() throws Throwable {
		label.setPrint();
	}

	@Then("^Label should be printed containing the Equipment code , User ID , Location ID$")
	public void label_should_be_printed_containing_the_Equipment_code_User_ID_Location_ID() throws Throwable {
		
	}

}
