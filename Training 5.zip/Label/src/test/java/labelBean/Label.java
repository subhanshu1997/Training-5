package labelBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Label {
	WebDriver driver;
	
	@FindBy(id="equipment")
	@CacheLookup
	WebElement equipment;
	
	@FindBy(id="user")
	@CacheLookup
	WebElement user;
	
	@FindBy(id="location")
	@CacheLookup
	WebElement location;
	
	@FindBy(partialLinkText="Print")
	@CacheLookup
	WebElement print;
	
	public Label(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getEquipment() {
		return equipment;
	}

	public void setEquipment(String equipment) {
		this.equipment.sendKeys(equipment);
	}

	public WebElement getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user.sendKeys(user);
	}

	public WebElement getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location.sendKeys(location);
	}

	public WebElement getPrint() {
		return print;
	}

	public void setPrint() {
		this.print.click();;
	}
	

}
