package stepDefinition;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {
	@Given("^I navigate to the login page$")
	public void i_navigate_to_the_login_page() throws Throwable {
	   System.out.println("I am at the login page");
	}

	@When("^I submit username and password$")
	public void i_submit_username_and_password() throws Throwable {
		System.out.println("i submit my username and password");
	}

	@Then("^I should be logged In$")
	public void i_should_be_logged_In() throws Throwable {
		System.out.println("I am logged on to the website");
	}

	@Given("^User search for Lenovo Laptop$")
	public void user_search_for_Lenovo_Laptop() throws Throwable {
		System.out.println("User searched for lenovo laptop");
	}

	@When("^Add the first laptop that appears in the search result to the basket$")
	public void add_the_first_laptop_that_appears_in_the_search_result_to_the_basket() throws Throwable {
		System.out.println("First search result added to bag");
	}

	@Then("^User basket should display with added item$")
	public void user_basket_should_display_with_added_item() throws Throwable {
		System.out.println("Bag is now contains the added product");
	}

	@Given("^User navigate for Lenovo Laptop$")
	public void user_navigate_for_Lenovo_Laptop() throws Throwable {
		System.out.println("User navigated for Lenovo Laptop");
	}

	@When("^Add the laptop to the basket$")
	public void add_the_laptop_to_the_basket() throws Throwable {
		System.out.println("Laptop added to the basket");
	}
	@Before(order=1)
	public void beforeScenario() {
		System.out.println("Start the browser and clear the cookies");
	}
	@Before(order=0)
	public void beforeScenarioStart() {
		System.out.println("---------------Start of scenario----------------");
	}
	@After(order=0)
	public void afterScenarioFinish() {
		System.out.println("-------------End of scenario--------------------");
	}
	@After(order=1)
	public void afterScenario() {
		System.out.println("Logout the user and close the browser");
	}

}
